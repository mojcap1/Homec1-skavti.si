# Homec1-spletnastran
Spletna stran za skavtski steg Homec 1 - homški sončki.
